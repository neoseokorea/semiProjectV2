THANK YOU FOR USING GLYPHICONS!

If you would like to be among the first ones to hear about all the news, follow @glyphicons on Twitter.

LICENSE:
------------------- 
GLYPHICONS FREE are released under Creative Commons Attribution-NoDerivs 3.0 Unported license. GLYPHICONS can be used both commercially and for personal use, but you must always add a link to www.glyphicons.com. You must not resell any icons or distribute them in any other way than referring to www.glyphicons.com. The Icons as such are the property of the author. The Icons cannot be placed on any other website or downloadable format.

All logos and trademarks in social icons are the property of the respective trademark owners.®

CONTACT:
-------------------
Web: http://glyphicons.com/
Email: glyphicons@gmail.com
Twitter: http://twitter.com/glyphicons

If you want to use the icons without restrictions, please buy any version on www.glyphicons.com, thank you.

Jan Kovařík
